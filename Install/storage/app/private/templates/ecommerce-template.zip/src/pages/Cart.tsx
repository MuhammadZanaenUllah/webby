import { ShoppingBag, Trash2, ArrowLeft, Plus, Minus, CreditCard, ShieldCheck, Truck, Zap } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Separator } from '../components/ui/separator';
import { SAMPLE_PRODUCTS } from '../lib/sample-data';
import { formatPrice } from '../lib/format';
import { toast } from 'sonner';

export default function Cart() {
  // Demo cart items
  const cartItems = [
    { ...SAMPLE_PRODUCTS[0], quantity: 1, size: 'M' },
    { ...SAMPLE_PRODUCTS[1], quantity: 2, size: 'L' }
  ];

  const subtotal = cartItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const shipping = 0;
  const tax = subtotal * 0.08;
  const total = subtotal + shipping + tax;

  const handleCheckout = () => {
    toast.success('Redirecting to Secure Checkout...');
  };

  return (
    <div className="min-h-screen bg-background pt-32 pb-24">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16 border-b border-border/50 pb-12">
          <div className="space-y-4">
            <Badge variant="secondary" className="px-4 py-1.5 rounded-full text-sm font-bold uppercase tracking-widest text-primary bg-primary/10">
              YOUR SELECTION
            </Badge>
            <h1 className="text-5xl md:text-7xl font-black text-foreground tracking-tight uppercase">MY <span className="text-primary italic">CART</span></h1>
          </div>
          <p className="text-xl font-bold text-muted-foreground italic">You have {cartItems.length} items in your collection.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          {/* Cart Items */}
          <div className="lg:col-span-8 space-y-8">
            {cartItems.length > 0 ? (
              <div className="space-y-6">
                {cartItems.map((item) => (
                  <div key={`${item.id}-${item.size}`} className="group relative flex flex-col sm:flex-row gap-8 bg-secondary/10 p-8 rounded-[3rem] border border-border/30 hover:border-primary/30 transition-all">
                    <div className="h-48 w-48 shrink-0 rounded-3xl overflow-hidden shadow-xl">
                       <img src={item.image} className="w-full h-full object-cover transition-transform group-hover:scale-110 duration-500" />
                    </div>
                    
                    <div className="flex-1 flex flex-col justify-between py-2">
                       <div className="flex justify-between items-start">
                          <div className="space-y-1">
                             <h3 className="text-2xl font-black uppercase tracking-tight group-hover:text-primary transition-colors">{item.name}</h3>
                             <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest">
                               Category: {item.category} <span className="mx-2">•</span> Size: {item.size}
                             </p>
                          </div>
                          <p className="text-2xl font-black text-foreground italic">{formatPrice(item.price)}</p>
                       </div>

                       <div className="flex items-center justify-between mt-8">
                          <div className="flex items-center bg-background rounded-full p-1 border border-border/50">
                             <Button variant="ghost" size="icon" className="h-10 w-10 rounded-full hover:bg-secondary">
                                <Minus className="h-4 w-4" />
                             </Button>
                             <span className="w-10 text-center font-black">{item.quantity}</span>
                             <Button variant="ghost" size="icon" className="h-10 w-10 rounded-full hover:bg-secondary">
                                <Plus className="h-4 w-4" />
                             </Button>
                          </div>
                          
                          <Button variant="ghost" className="text-destructive h-12 px-6 font-black hover:bg-destructive/10 rounded-2xl gap-2">
                             <Trash2 className="h-5 w-5" /> REMOVE
                          </Button>
                       </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-24 text-center space-y-8 bg-secondary/10 rounded-[3rem] border-2 border-dashed border-border/50">
                 <div className="h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center mx-auto">
                    <ShoppingBag className="h-12 w-12 text-primary opacity-50" />
                 </div>
                 <h2 className="text-4xl font-black tracking-tight uppercase">Your cart is empty</h2>
                 <Button size="lg" className="h-16 px-12 rounded-full text-xl font-black">START EXPLORING</Button>
              </div>
            )}
            
            <Button variant="ghost" className="h-16 px-8 rounded-full font-black text-lg gap-3 hover:bg-secondary">
               <ArrowLeft className="h-6 w-6" /> CONTINUE SHOPPING
            </Button>
          </div>

          {/* Summary Sidebar */}
          <div className="lg:col-span-4">
            <div className="bg-secondary/20 p-10 rounded-[3rem] border border-border/50 sticky top-32 space-y-10 shadow-2xl shadow-primary/5">
               <h2 className="text-3xl font-black uppercase tracking-tight border-b border-border/50 pb-6">SUMMARY</h2>
               
               <div className="space-y-6">
                 <div className="flex justify-between items-center text-lg">
                    <span className="font-bold text-muted-foreground uppercase tracking-widest">SUBTOTAL</span>
                    <span className="font-black text-foreground">{formatPrice(subtotal)}</span>
                 </div>
                 <div className="flex justify-between items-center text-lg">
                    <span className="font-bold text-muted-foreground uppercase tracking-widest">SHIPPING</span>
                    <span className="font-black text-primary italic">FREE</span>
                 </div>
                 <div className="flex justify-between items-center text-lg">
                    <span className="font-bold text-muted-foreground uppercase tracking-widest">TAX (EST.)</span>
                    <span className="font-black text-foreground">{formatPrice(tax)}</span>
                 </div>
                 
                 <Separator className="bg-border/50" />
                 
                 <div className="flex justify-between items-end pt-4">
                    <span className="text-2xl font-black uppercase italic tracking-tighter">TOTAL PAYABLE</span>
                    <span className="text-4xl font-black text-primary underline decoration-4 decoration-primary/20 underline-offset-8">
                       {formatPrice(total)}
                    </span>
                 </div>
               </div>

               <div className="space-y-4 pt-6">
                 <Button 
                   className="w-full h-20 rounded-full text-xl font-black shadow-2xl shadow-primary/20 gap-3 group"
                   onClick={handleCheckout}
                 >
                    SECURE CHECKOUT <CreditCard className="h-6 w-6 group-hover:rotate-12 transition-transform" />
                 </Button>
                 <p className="text-center text-xs font-bold text-muted-foreground uppercase tracking-widest flex items-center justify-center gap-2">
                    <ShieldCheck className="h-4 w-4 text-emerald-500" /> ENCRYPTED BY WEBBY PAY
                 </p>
               </div>

               <div className="pt-8 space-y-6">
                  <div className="flex items-center gap-4 group">
                     <div className="h-12 w-12 rounded-full bg-background flex items-center justify-center border border-border group-hover:scale-110 transition-transform shadow-sm">
                        <Truck className="h-6 w-6 text-primary" />
                     </div>
                     <div>
                        <p className="font-black text-xs uppercase tracking-tighter">Global Logistics</p>
                        <p className="text-sm font-bold text-muted-foreground italic">Arriving in 3-5 days</p>
                     </div>
                  </div>
                  <div className="flex items-center gap-4 group">
                     <div className="h-12 w-12 rounded-full bg-background flex items-center justify-center border border-border group-hover:scale-110 transition-transform shadow-sm">
                        <Zap className="h-6 w-6 text-primary" />
                     </div>
                     <div>
                        <p className="font-black text-xs uppercase tracking-tighter">Priority Pack</p>
                        <p className="text-sm font-bold text-muted-foreground italic">Anti-damage guarantee</p>
                     </div>
                  </div>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

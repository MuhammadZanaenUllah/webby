import { useState, useMemo } from 'react';
import { Search, SlidersHorizontal, LayoutGrid, List, ChevronDown, ShoppingBag } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '../components/ui/dropdown-menu';
import { ProductCard } from '../components/ProductCard';
import { SAMPLE_PRODUCTS, CATEGORIES } from '../lib/sample-data';
import { toast } from 'sonner';

export default function Products() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [sortBy, setSortBy] = useState('Newest');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  const filteredAndSortedProducts = useMemo(() => {
    let result = [...SAMPLE_PRODUCTS];

    // Filter by Category
    if (selectedCategory !== 'All') {
      result = result.filter(p => p.category === selectedCategory);
    }

    // Search Query
    if (searchQuery) {
      result = result.filter(p => 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        p.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Sorting
    switch (sortBy) {
      case 'Price: Low to High':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'Price: High to Low':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'Top Rated':
        result.sort((a, b) => b.rating - a.rating);
        break;
      default: // Newest
        result.sort((a, b) => parseInt(b.id) - parseInt(a.id));
    }

    return result;
  }, [searchQuery, selectedCategory, sortBy]);

  const handleAddToCart = (product: any) => {
    toast.success(`Exclusive ${product.name} added to cart!`);
  };

  return (
    <div className="min-h-screen bg-background pt-24 pb-24">
      <div className="container mx-auto px-6">
        {/* Header & Search */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 mb-16 border-b border-border/50 pb-12">
          <div className="space-y-4">
            <Badge variant="secondary" className="px-4 py-1.5 rounded-full text-sm font-bold uppercase tracking-widest text-primary bg-primary/10">
              The Collection
            </Badge>
            <h1 className="text-5xl md:text-7xl font-black text-foreground tracking-tight uppercase">EVERYTHING <br /><span className="text-primary italic">YOU NEED</span></h1>
          </div>
          <div className="relative max-w-md w-full">
            <div className="absolute left-6 top-1/2 -translate-y-1/2 text-muted-foreground">
               <Search className="h-6 w-6" />
            </div>
            <Input 
              placeholder="Search lifestyle products..." 
              className="h-16 pl-16 pr-8 rounded-full bg-secondary/30 border-none text-lg font-medium focus-visible:ring-2 focus-visible:ring-primary shadow-inner"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {/* Filters and View Controls */}
        <div className="flex flex-col lg:flex-row gap-8 items-start lg:items-center justify-between mb-12 py-4 border-y border-border/30 bg-secondary/5 px-6 rounded-3xl">
          <div className="flex items-center gap-4 overflow-x-auto pb-2 lg:pb-0 no-scrollbar">
            {CATEGORIES.map((cat) => (
              <button
                key={cat.name}
                onClick={() => setSelectedCategory(cat.name)}
                className={`whitespace-nowrap px-8 py-3 rounded-full text-sm font-black transition-all ${
                  selectedCategory === cat.name 
                  ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/20 scale-105' 
                  : 'text-muted-foreground hover:text-foreground hover:bg-secondary'
                }`}
              >
                {cat.name.toUpperCase()}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-6 w-full lg:w-auto">
            <div className="flex items-center gap-2 p-1.5 bg-secondary/50 rounded-2xl hidden sm:flex">
              <Button 
                variant={viewMode === 'grid' ? 'secondary' : 'ghost'} 
                size="icon" 
                className={`rounded-xl ${viewMode === 'grid' ? 'shadow-sm bg-background' : ''}`}
                onClick={() => setViewMode('grid')}
              >
                <LayoutGrid className="h-5 w-5" />
              </Button>
              <Button 
                variant={viewMode === 'list' ? 'secondary' : 'ghost'} 
                size="icon" 
                className={`rounded-xl ${viewMode === 'list' ? 'shadow-sm bg-background' : ''}`}
                onClick={() => setViewMode('list')}
              >
                <List className="h-5 w-5" />
              </Button>
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="h-14 px-8 rounded-2xl font-black border-2 flex-1 lg:flex-none">
                  SORT: {sortBy.toUpperCase()} <ChevronDown className="ml-2 h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 p-2 rounded-2xl">
                {['Newest', 'Top Rated', 'Price: Low to High', 'Price: High to Low'].map((s) => (
                  <DropdownMenuItem 
                    key={s} 
                    className={`rounded-xl p-3 font-bold ${sortBy === s ? 'bg-primary/10 text-primary' : ''}`}
                    onClick={() => setSortBy(s)}
                  >
                    {s}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
            
            <Button size="icon" variant="secondary" className="h-14 w-14 rounded-2xl shrink-0">
               <SlidersHorizontal className="h-6 w-6" />
            </Button>
          </div>
        </div>

        {/* Status Info */}
        <div className="flex items-center justify-between mb-8 px-2">
          <p className="text-lg font-bold text-muted-foreground tracking-tight">
            Showing <span className="text-foreground">{filteredAndSortedProducts.length}</span> results 
            {selectedCategory !== 'All' && <span> in <span className="text-primary italic">{selectedCategory}</span></span>}
          </p>
        </div>

        {/* Results Grid */}
        {filteredAndSortedProducts.length > 0 ? (
          <div className={`grid gap-8 ${
            viewMode === 'grid' 
            ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4' 
            : 'grid-cols-1'
          }`}>
            {filteredAndSortedProducts.map((product) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
        ) : (
          <div className="py-32 flex flex-col items-center justify-center text-center space-y-6 bg-secondary/5 rounded-[3rem] border border-dashed border-border/50">
            <div className="h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center">
               <ShoppingBag className="h-12 w-12 text-primary opacity-50" />
            </div>
            <div className="space-y-2">
              <h3 className="text-3xl font-black text-foreground">NO MATCHES FOUND</h3>
              <p className="text-xl text-muted-foreground">Adjust your filters or search query to find more lifestyle essentials.</p>
            </div>
            <Button size="lg" className="h-16 px-10 rounded-full font-black mt-4" onClick={() => {
              setSearchQuery('');
              setSelectedCategory('All');
            }}>
              RESET FILTERS
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}

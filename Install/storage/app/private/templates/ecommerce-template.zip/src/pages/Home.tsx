import { useState } from 'react';
import { ShoppingBag, ArrowRight, Truck, ShieldCheck, Zap, Menu } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card, CardContent } from '../components/ui/card';
import { ProductCard, CategoryCard } from '../components/ProductCard';
import { SAMPLE_PRODUCTS, CATEGORIES } from '../lib/sample-data';
import { Badge } from '../components/ui/badge';
import { toast } from 'sonner';

export default function Home() {
  const [activeCategory, setActiveCategory] = useState('All');

  const filteredProducts = activeCategory === 'All' 
    ? SAMPLE_PRODUCTS 
    : SAMPLE_PRODUCTS.filter(p => p.category === activeCategory);

  const handleAddToCart = (product: any) => {
    toast.success(`${product.name} added to cart!`);
  };

  return (
    <div className="flex flex-col min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative h-[85vh] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?q=80&w=2000&auto=format&fit=crop" 
            className="w-full h-full object-cover brightness-[0.4]"
            alt="Hero Background"
          />
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-2xl space-y-8">
            <Badge variant="secondary" className="bg-primary/20 text-primary border-none py-1.5 px-4 text-sm font-bold uppercase tracking-widest">
              Summer Collection 2026
            </Badge>
            <h1 className="text-6xl md:text-8xl font-black text-white leading-tight">
              ELEVATE YOUR <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-400">DAILY VIBE</span>
            </h1>
            <p className="text-xl text-zinc-300 max-w-lg leading-relaxed">
              Curated essentials for the modern lifestyle. Quality materials, ethical production, and timeless aesthetics.
            </p>
            <div className="flex flex-wrap gap-4 pt-4">
              <Button size="lg" className="h-16 px-10 text-lg font-bold rounded-full shadow-2xl shadow-primary/25">
                Shop Collection <ShoppingBag className="ml-2 h-6 w-6" />
              </Button>
              <Button size="lg" variant="outline" className="h-16 px-10 text-lg font-bold rounded-full text-white border-white/20 hover:bg-white/10">
                Our Story
              </Button>
            </div>
          </div>
        </div>
        
        {/* Floating Stats */}
        <div className="absolute bottom-12 right-12 hidden lg:flex flex-col gap-6 z-10">
          {[
            { label: 'Sold Units', val: '150K+' },
            { label: 'Happy Users', val: '98%' },
            { label: 'Countries', val: '45+' }
          ].map((stat, i) => (
            <div key={i} className="bg-white/5 backdrop-blur-xl border border-white/10 p-6 rounded-3xl min-w-[200px]">
              <p className="text-3xl font-black text-white mb-1">{stat.val}</p>
              <p className="text-sm text-zinc-400 uppercase tracking-widest font-semibold">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Trust Badges */}
      <section className="py-12 border-y border-border/50 bg-secondary/20">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="flex items-center gap-4 group">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                <Truck className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-bold text-foreground">Free Shipping</p>
                <p className="text-xs text-muted-foreground">Orders over $100</p>
              </div>
            </div>
            <div className="flex items-center gap-4 group">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                <ShieldCheck className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-bold text-foreground">Secure Payment</p>
                <p className="text-xs text-muted-foreground">100% encryption</p>
              </div>
            </div>
            <div className="flex items-center gap-4 group">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-bold text-foreground">Fast Support</p>
                <p className="text-xs text-muted-foreground">24/7 dedicated</p>
              </div>
            </div>
            <div className="flex items-center gap-4 group">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center text-primary group-hover:scale-110 transition-transform">
                <ArrowRight className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-bold text-foreground">90 Day Return</p>
                <p className="text-xs text-muted-foreground">No questions asked</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Shop by Category */}
      <section className="py-24">
        <div className="container mx-auto px-6">
          <div className="flex items-end justify-between mb-12">
            <div className="space-y-4">
              <h2 className="text-4xl md:text-5xl font-black text-foreground">EXPLORE THE <span className="text-primary">ESSENTIALS</span></h2>
              <p className="text-lg text-muted-foreground max-w-xl">
                Browse our curated collection of lifestyle products designed for aesthetic utility.
              </p>
            </div>
            <Button variant="ghost" className="text-lg font-bold hover:text-primary">
              View All Categories <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <CategoryCard name="Tech & Gadgets" count={42} image="https://images.unsplash.com/photo-1468436139062-f60a71c5c892?q=80&w=800&auto=format&fit=crop" />
            <CategoryCard name="Modern Apparel" count={28} image="https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?q=80&w=800&auto=format&fit=crop" />
            <CategoryCard name="Home & Decor" count={15} image="https://images.unsplash.com/photo-1513519245088-0e12902e5a38?q=80&w=800&auto=format&fit=crop" />
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 bg-secondary/10">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-8 mb-16">
            <h2 className="text-4xl font-black text-foreground tracking-tight">FEATURED <span className="text-primary">OFFERS</span></h2>
            <div className="flex p-1 bg-background border border-border rounded-full flex-wrap">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.name}
                  onClick={() => setActiveCategory(cat.name)}
                  className={`px-8 py-3 rounded-full text-sm font-bold transition-all ${
                    activeCategory === cat.name 
                    ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/20' 
                    : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {filteredProducts.map((product) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                onAddToCart={handleAddToCart}
              />
            ))}
          </div>
          <div className="mt-16 text-center">
            <Button size="lg" variant="outline" className="h-16 px-12 text-lg font-black rounded-full border-2 hover:bg-primary hover:text-primary-foreground border-primary text-primary transition-all">
              DISCOVER FULL COLLECTION
            </Button>
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="py-24 overflow-hidden relative">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-full bg-primary rotate-2 z-0 opacity-10 blur-3xl"></div>
        <div className="container mx-auto px-6 relative z-10">
          <div className="bg-primary text-primary-foreground rounded-[3rem] p-12 md:p-24 overflow-hidden relative">
            <div className="max-w-3xl space-y-8 relative z-10">
              <h2 className="text-5xl md:text-7xl font-black tracking-tight leading-tight">JOIN THE ESSENTIALS REVOLUTION</h2>
              <p className="text-xl text-primary-foreground/80 font-medium">
                Be the first to hear about new drops, exclusive collections, and zero-impact lifestyle tips. No spam, just pure vibe.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <input 
                  type="email" 
                  placeholder="Enter your email" 
                  className="h-16 flex-1 px-8 rounded-full bg-white/10 border border-white/20 text-white placeholder:text-white/40 focus:outline-none focus:ring-2 focus:ring-white/50 text-lg font-medium"
                />
                <Button variant="secondary" className="h-16 px-12 rounded-full text-lg font-black hover:scale-105 transition-transform">
                  SUBSCRIBE NOW
                </Button>
              </div>
            </div>
            
            <div className="absolute right-0 top-0 h-full w-1/3 opacity-20 pointer-events-none hidden lg:block">
               <img src="https://images.unsplash.com/photo-1523381210434-271e8be1f52b?q=80&w=800&auto=format&fit=crop" className="w-full h-full object-cover rounded-l-full" />
            </div>
          </div>
        </div>
      </section>

      {/* Minimal Footer Info */}
      <footer className="py-12 border-t border-border/50">
        <div className="container mx-auto px-6 text-center text-muted-foreground">
          <p className="font-bold text-lg mb-2">WEBBY STORE</p>
          <p className="text-sm">© 2026 Webby Builder Templates. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

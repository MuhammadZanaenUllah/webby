import { useState } from 'react';
import { 
  Star, 
  Minus, 
  Plus, 
  ShoppingCart, 
  Heart, 
  Share2, 
  Truck, 
  ShieldCheck, 
  ArrowLeft,
  ChevronRight,
  Zap,
  Info
} from 'lucide-react';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Separator } from '../components/ui/separator';
import { SAMPLE_PRODUCTS } from '../lib/sample-data';
import { formatPrice } from '../lib/format';
import { toast } from 'sonner';

export default function ProductDetail() {
  const [quantity, setQuantity] = useState(1);
  const [selectedSize, setSelectedSize] = useState('M');
  const [activeImage, setActiveImage] = useState(0);

  // For demo, we use the first product
  const product = SAMPLE_PRODUCTS[0];
  const images = [
    product.image,
    'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1526170315830-ef18a25d18ad?q=80&w=800&auto=format&fit=crop',
    'https://images.unsplash.com/photo-1572635196237-14b3f281503f?q=80&w=800&auto=format&fit=crop'
  ];

  const handleAddToCart = () => {
    toast.success(`${quantity}x ${product.name} added to your cart!`);
  };

  return (
    <div className="min-h-screen bg-background pt-32 pb-24">
      <div className="container mx-auto px-6">
        {/* Breadcrumbs */}
        <nav className="flex items-center gap-4 mb-12 text-sm font-bold tracking-widest text-muted-foreground uppercase">
          <a href="/" className="hover:text-primary transition-colors">HOME</a>
          <ChevronRight className="h-4 w-4" />
          <a href="/products" className="hover:text-primary transition-colors">SHOP</a>
          <ChevronRight className="h-4 w-4" />
          <span className="text-foreground italic">{product.name}</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          {/* Image Gallery */}
          <div className="lg:col-span-7 space-y-6">
             <div className="aspect-square rounded-[3rem] overflow-hidden bg-secondary/20 border border-border shadow-2xl shadow-primary/5">
                <img 
                  src={images[activeImage]} 
                  alt={product.name} 
                  className="w-full h-full object-cover transition-all duration-700 hover:scale-110" 
                />
             </div>
             <div className="grid grid-cols-4 gap-4">
                {images.map((img, i) => (
                  <button 
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`aspect-square rounded-2xl overflow-hidden border-4 transition-all ${
                      activeImage === i 
                      ? 'border-primary shadow-lg shadow-primary/20 scale-105' 
                      : 'border-transparent opacity-60 hover:opacity-100 hover:border-border'
                    }`}
                  >
                    <img src={img} alt={`${product.name} ${i}`} className="w-full h-full object-cover" />
                  </button>
                ))}
             </div>
          </div>

          {/* Product Info */}
          <div className="lg:col-span-5 space-y-10">
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <Badge className="px-4 py-1.5 rounded-full text-xs font-black bg-primary/10 text-primary uppercase border-none tracking-widest">
                  TRENDING NOW
                </Badge>
                <div className="flex items-center gap-1.5 px-3 py-1 bg-secondary/50 rounded-full text-sm font-bold">
                  <Star className="h-4 w-4 fill-yellow-500 text-yellow-500" />
                  <span>{product.rating} / 5.0</span>
                  <span className="text-muted-foreground ml-1">({product.reviews} reviews)</span>
                </div>
              </div>

              <h1 className="text-5xl md:text-6xl font-black text-foreground leading-tight tracking-tight uppercase">
                {product.name}
              </h1>
              
              <div className="flex items-baseline gap-6">
                <span className="text-4xl font-black text-primary italic">
                  {formatPrice(product.price)}
                </span>
                <span className="text-lg font-bold text-muted-foreground uppercase tracking-widest">
                  FREE SHIPPING INCLUDED
                </span>
              </div>

              <p className="text-xl text-muted-foreground leading-relaxed">
                {product.description} Crafted with recycled materials and sustainable processes, without compromising an inch on the modern aesthetic.
              </p>
            </div>

            <Separator className="bg-border/50" />

            {/* Options */}
            <div className="space-y-8">
               <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-black uppercase tracking-widest text-foreground">Select Variant</label>
                    <button className="text-xs font-bold text-primary hover:underline italic">PRO - SIZE GUIDE</button>
                  </div>
                  <div className="flex flex-wrap gap-3">
                    {['S', 'M', 'L', 'XL'].map((size) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSize(size)}
                        className={`h-14 w-20 rounded-2xl text-lg font-black transition-all border-2 ${
                          selectedSize === size
                          ? 'bg-primary border-primary text-primary-foreground shadow-lg shadow-primary/30 scale-110'
                          : 'border-border text-foreground hover:border-primary/50'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
               </div>

               <div className="flex flex-col sm:flex-row gap-6">
                  <div className="flex items-center bg-secondary/50 rounded-full p-2 h-20 border border-border/50 shadow-inner">
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      className="h-14 w-14 rounded-full font-black text-2xl hover:bg-background"
                    >
                      <Minus className="h-6 w-6" />
                    </Button>
                    <span className="w-16 text-center text-2xl font-black">{quantity}</span>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => setQuantity(quantity + 1)}
                      className="h-14 w-14 rounded-full font-black text-2xl hover:bg-background"
                    >
                      <Plus className="h-6 w-6" />
                    </Button>
                  </div>
                  
                  <Button 
                    className="h-20 flex-1 rounded-full text-xl font-black shadow-2xl shadow-primary/20 gap-3 group"
                    onClick={handleAddToCart}
                  >
                    ADD TO MY COLLECTION <ShoppingCart className="h-7 w-7 group-hover:translate-x-1 transition-transform" />
                  </Button>
               </div>
               
               <div className="flex gap-4">
                  <Button variant="outline" className="h-14 rounded-2xl flex-1 font-bold border-2 hover:bg-secondary">
                    <Heart className="mr-2 h-5 w-5" /> FAVORITE
                  </Button>
                  <Button variant="outline" className="h-14 rounded-2xl flex-1 font-bold border-2 hover:bg-secondary">
                    <Share2 className="mr-2 h-5 w-5" /> SHARE VIBE
                  </Button>
               </div>
            </div>

            {/* Delivery / Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-6">
               <div className="flex items-center gap-4 p-5 rounded-3xl bg-primary/5 border border-primary/10">
                  <Truck className="h-7 w-7 text-primary" />
                  <div>
                    <p className="font-black text-xs uppercase tracking-tighter">Fast Standard</p>
                    <p className="text-sm font-bold text-muted-foreground italic">2-4 Business Days</p>
                  </div>
               </div>
               <div className="flex items-center gap-4 p-5 rounded-3xl bg-primary/5 border border-primary/10">
                  <ShieldCheck className="h-7 w-7 text-primary" />
                  <div>
                    <p className="font-black text-xs uppercase tracking-tighter">Certified Authenticity</p>
                    <p className="text-sm font-bold text-muted-foreground italic">100% Genuine Tag</p>
                  </div>
               </div>
            </div>
          </div>
        </div>

        {/* Detailed Info Tabs */}
        <div className="mt-32">
          <Tabs defaultValue="details" className="w-full">
            <TabsList className="bg-transparent border-b border-border/50 w-full justify-start rounded-none h-auto p-0 gap-12 mb-12">
              <TabsTrigger 
                value="details" 
                className="rounded-none border-b-4 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent text-xl font-black uppercase pb-6 tracking-widest px-0 transition-all opacity-40 data-[state=active]:opacity-100"
              >
                THE CRAFT
              </TabsTrigger>
              <TabsTrigger 
                value="shipping" 
                className="rounded-none border-b-4 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent text-xl font-black uppercase pb-6 tracking-widest px-0 transition-all opacity-40 data-[state=active]:opacity-100"
              >
                SHIPPING & CARE
              </TabsTrigger>
              <TabsTrigger 
                value="reviews" 
                className="rounded-none border-b-4 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent text-xl font-black uppercase pb-6 tracking-widest px-0 transition-all opacity-40 data-[state=active]:opacity-100"
              >
                COMMUNITY REVIEWS
              </TabsTrigger>
            </TabsList>
            
            <TabsContent value="details" className="bg-secondary/10 p-12 rounded-[3rem] border border-border/30">
              <div className="grid md:grid-cols-2 gap-16 items-center">
                <div className="space-y-8">
                   <h3 className="text-4xl font-black uppercase leading-tight italic">DESIGNED FOR THE <br /> MODERN MINIMALIST</h3>
                   <p className="text-xl text-muted-foreground leading-relaxed">
                     Every stitch and surface is considered. We spent 14 months iterating on this specific model to ensure it meets our "Vibe Standard" - balancing bold identity with everyday utility.
                   </p>
                   <ul className="space-y-4">
                      {[
                        'High-tensile sustainable alloy casing',
                        'Sapphire-grade reinforced crystal',
                        'Precision-milled aerospace aluminum components',
                        'Anti-glare micro-coating for better visibility'
                      ].map((item, i) => (
                        <li key={i} className="flex items-center gap-4 text-lg font-bold">
                          <Zap className="h-5 w-5 text-primary fill-primary" /> {item}
                        </li>
                      ))}
                   </ul>
                </div>
                <div className="rounded-[2rem] overflow-hidden shadow-2xl">
                   <img src="https://images.unsplash.com/photo-1524805444758-089113d48a6d?q=80&w=800&auto=format&fit=crop" />
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="shipping" className="bg-secondary/10 p-12 rounded-[3rem] border border-border/30">
              <div className="max-w-3xl space-y-8">
                 <h3 className="text-3xl font-black uppercase italic">GLOBAL LOGISTICS & PRODUCT DURABILITY</h3>
                 <div className="grid sm:grid-cols-2 gap-12">
                   <div className="space-y-4">
                      <h4 className="text-xl font-black flex items-center gap-3">
                        <Truck className="h-6 w-6 text-primary" /> DELIVERY
                      </h4>
                      <p className="text-lg text-muted-foreground">
                        We ship to over 120 countries using carbon-neutral logistics providers. Orders are processed within 24 hours of receipt.
                      </p>
                   </div>
                   <div className="space-y-4">
                      <h4 className="text-xl font-black flex items-center gap-3">
                        <Info className="h-6 w-6 text-primary" /> CARE INSTRUCTIONS
                      </h4>
                      <p className="text-lg text-muted-foreground">
                        Clean with a soft, lint-free cloth. Avoid chemical detergents. If item is tech-related, keep firmware updated via our app.
                      </p>
                   </div>
                 </div>
              </div>
            </TabsContent>

            <TabsContent value="reviews" className="bg-secondary/10 p-12 rounded-[3rem] border border-border/30">
               <div className="space-y-12">
                  <div className="flex items-center justify-between pb-8 border-b border-border/30">
                    <h3 className="text-3xl font-black uppercase italic">COMMUNITY FEEDBACK ({product.reviews})</h3>
                    <Button className="rounded-full h-14 px-8 font-black">WRITE A REVIEW</Button>
                  </div>
                  <div className="grid md:grid-cols-2 gap-8">
                    {[1, 2, 3, 4].map((r) => (
                      <div key={r} className="bg-background p-8 rounded-3xl border border-border/50 shadow-sm">
                        <div className="flex items-center justify-between mb-4">
                           <div className="flex items-center gap-3">
                              <div className="h-10 w-10 rounded-full bg-primary/20 flex items-center justify-center font-black">U{r}</div>
                              <div>
                                <p className="font-black text-sm uppercase">User_{r}24</p>
                                <p className="text-xs text-muted-foreground italic tracking-widest">Verified Collector</p>
                              </div>
                           </div>
                           <div className="flex gap-0.5">
                              {[1, 2, 3, 4, 5].map((s) => <Star key={s} className="h-4 w-4 fill-yellow-500 text-yellow-500" />)}
                           </div>
                        </div>
                        <p className="text-lg font-bold italic mb-2">"Found my new daily driver!"</p>
                        <p className="text-muted-foreground leading-relaxed">
                          Absolutely blown away by the quality. The attention to detail is evident from the moment you unbox it. Best purchase I've made this year.
                        </p>
                      </div>
                    ))}
                  </div>
               </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}

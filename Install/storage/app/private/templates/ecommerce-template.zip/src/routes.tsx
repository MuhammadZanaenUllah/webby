import { createBrowserRouter, RouterProvider, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import Home from './pages/Home';
import Products from './pages/Products';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import NotFound from './pages/NotFound';
import { ProtectedRoute } from './components/ProtectedRoute';

// Route configuration with layout and auth settings
export const routes = [
  {
    path: '/',
    element: <Home />,
    name: 'Home',
    showInNav: true,
    layout: 'default'
  },
  {
    path: '/products',
    element: <Products />,
    name: 'Shop',
    showInNav: true,
    layout: 'default'
  },
  {
    path: '/product/:id',
    element: <ProductDetail />,
    name: 'Product Details',
    showInNav: false,
    layout: 'default'
  },
  {
    path: '/cart',
    element: <Cart />,
    name: 'Cart',
    showInNav: true,
    layout: 'default'
  },
  {
    path: '/account',
    element: (
      <ProtectedRoute>
        <div className="pt-32 pb-24 container mx-auto px-6 font-black text-4xl">MY ACCOUNT COLLECTION</div>
      </ProtectedRoute>
    ),
    name: 'Account',
    showInNav: false,
    layout: 'default'
  },
  {
    path: '*',
    element: <NotFound />,
    name: '404',
    showInNav: false,
    layout: 'default'
  }
];

const router = createBrowserRouter(
  routes.map((route) => ({
    path: route.path,
    element: route.layout === 'default' ? <Layout>{route.element}</Layout> : route.element
  }))
);

export function Routes() {
  return <RouterProvider router={router} />;
}

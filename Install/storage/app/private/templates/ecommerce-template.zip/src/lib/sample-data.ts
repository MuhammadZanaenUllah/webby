export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  rating: number;
  reviews: number;
  stock: number;
  isNew?: boolean;
  isSale?: boolean;
  discountPrice?: number;
}

export const SAMPLE_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Classic Chronograph Watch',
    description: 'Timeless design meets modern precision. Genuine leather strap, water-resistant up to 50m.',
    price: 195.00,
    category: 'Accessories',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?q=80&w=800&auto=format&fit=crop',
    rating: 4.8,
    reviews: 124,
    stock: 12
  },
  {
    id: '2',
    name: 'Wireless Noise-Cancelling Headphones',
    description: 'Immerse yourself in sound. 40-hour battery life, ergonomic ear cups, studio-quality audio.',
    price: 299.00,
    category: 'Electronics',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?q=80&w=800&auto=format&fit=crop',
    rating: 4.9,
    reviews: 215,
    stock: 8,
    isNew: true
  },
  {
    id: '3',
    name: 'Organic Cotton Premium Hoodie',
    description: 'Sustainable comfort for every day. Heavyweight organic cotton, fleece lining, relaxed fit.',
    price: 85.00,
    category: 'Apparel',
    image: 'https://images.unsplash.com/photo-1556819854-4740e53a31c5?q=80&w=800&auto=format&fit=crop',
    rating: 4.6,
    reviews: 56,
    stock: 25,
    isSale: true,
    discountPrice: 65.00
  },
  {
    id: '4',
    name: 'Ceramic Minimalist Vase',
    description: 'Handcrafted ceramic with a matte finish. Perfect for any modern living space.',
    price: 45.00,
    category: 'Home Decore',
    image: 'https://images.unsplash.com/photo-1581783898377-1c85bf937427?q=80&w=800&auto=format&fit=crop',
    rating: 4.7,
    reviews: 89,
    stock: 10
  }
];

export const CATEGORIES = [
  { name: 'All', count: 64 },
  { name: 'Accessories', count: 12 },
  { name: 'Electronics', count: 18 },
  { name: 'Apparel', count: 24 },
  { name: 'Home Decore', count: 10 }
];

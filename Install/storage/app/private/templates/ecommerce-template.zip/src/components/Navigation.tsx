import { useState, useEffect } from 'react';
import { 
  ShoppingBag, 
  User, 
  Search, 
  Menu, 
  X, 
  ChevronRight, 
  TrendingUp, 
  Zap,
  Package,
  Heart
} from 'lucide-react';
import { Button } from './ui/button';
import { ThemeToggle } from './ThemeToggle';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from './ui/dropdown-menu';
import { Badge } from './ui/badge';
import { useAuth } from '../hooks/useAuth';

export function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, signOut, isAuthenticated } = useAuth();
  const cartCount = 3; // Demo count

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Shop All', href: '/products', icon: Package },
    { name: 'Trending', href: '#', icon: TrendingUp },
    { name: 'New Drops', href: '#', icon: Zap },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
      isScrolled 
      ? 'h-20 bg-background/80 backdrop-blur-2xl border-b border-border/50 shadow-xl shadow-primary/5' 
      : 'h-28 bg-transparent'
    }`}>
      <div className="container mx-auto h-full px-6 flex items-center justify-between">
        {/* Mobile Menu Toggle */}
        <Button 
          variant="ghost" 
          size="icon" 
          className="lg:hidden h-12 w-12 rounded-2xl hover:bg-secondary"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </Button>

        {/* Logo */}
        <a href="/" className="flex items-center gap-3 group">
          <div className="h-12 w-12 rounded-[1rem] bg-primary flex items-center justify-center text-primary-foreground shadow-2xl shadow-primary/40 group-hover:rotate-12 transition-transform">
            <ShoppingBag className="h-7 w-7" />
          </div>
          <span className={`text-2xl font-black tracking-tighter uppercase ${isScrolled ? 'text-foreground' : 'text-white'}`}>
            WEBBY <span className="text-primary italic">STORE</span>
          </span>
        </a>

        {/* Desktop Navigation */}
        <div className="hidden lg:flex items-center gap-10">
          {navLinks.map((link) => (
            <a 
              key={link.name} 
              href={link.href} 
              className={`text-sm font-black uppercase tracking-widest transition-all hover:text-primary relative group flex items-center gap-2 ${
                isScrolled ? 'text-muted-foreground' : 'text-white/80'
              }`}
            >
              {link.name}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary transition-all group-hover:w-full"></span>
            </a>
          ))}
        </div>

        {/* Action Icons */}
        <div className="flex items-center gap-4 sm:gap-6">
          <Button 
            variant="ghost" 
            size="icon" 
            className={`h-12 w-12 rounded-2xl hover:bg-secondary transition-colors ${isScrolled ? 'text-foreground' : 'text-white'}`}
          >
            <Search className="h-6 w-6" />
          </Button>
          
          <div className="hidden sm:block">
            <ThemeToggle />
          </div>

          {/* Cart */}
          <a href="/cart" className="relative group">
            <Button 
              variant="ghost" 
              size="icon" 
              className={`h-12 w-12 rounded-2xl hover:bg-secondary transition-colors ${isScrolled ? 'text-foreground' : 'text-white'}`}
            >
              <ShoppingBag className="h-6 w-6" />
              {cartCount > 0 && (
                <Badge className="absolute -top-1 -right-1 h-6 w-6 flex items-center justify-center p-0 rounded-full bg-primary text-primary-foreground border-4 border-background animate-pulse font-black text-[10px]">
                  {cartCount}
                </Badge>
              )}
            </Button>
          </a>

          {/* User Account */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                size="icon" 
                className={`h-12 w-12 rounded-2xl hover:bg-secondary transition-colors overflow-hidden ${isScrolled ? 'text-foreground' : 'text-white'}`}
              >
                {isAuthenticated ? (
                  <div className="h-full w-full bg-primary/20 flex items-center justify-center font-black">
                     {user?.email?.[0].toUpperCase()}
                  </div>
                ) : (
                  <User className="h-6 w-6" />
                )}
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-64 p-3 rounded-3xl mt-2 border-border/50 shadow-2xl">
              {isAuthenticated ? (
                <>
                  <div className="px-3 py-4 mb-2">
                     <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-1">Signed in as</p>
                     <p className="font-black text-foreground truncate">{user?.email}</p>
                  </div>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem className="rounded-2xl p-4 font-bold gap-3 focus:bg-primary/10">
                     <User className="h-5 w-5" /> Account Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem className="rounded-2xl p-4 font-bold gap-3 focus:bg-primary/10">
                     <Package className="h-5 w-5" /> My Orders
                  </DropdownMenuItem>
                  <DropdownMenuItem className="rounded-2xl p-4 font-bold gap-3 focus:bg-primary/10">
                     <Heart className="h-5 w-5" /> Wishlist
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem 
                    className="rounded-2xl p-4 font-bold gap-3 text-destructive focus:bg-destructive/10"
                    onClick={() => signOut()}
                  >
                     Log Out
                  </DropdownMenuItem>
                </>
              ) : (
                <>
                   <div className="px-3 py-4 text-center">
                     <h3 className="font-black text-lg mb-1 tracking-tight">JOIN THE CLUB</h3>
                     <p className="text-sm text-muted-foreground">Unlock exclusive drops and priority shipping.</p>
                   </div>
                   <DropdownMenuSeparator />
                   <DropdownMenuItem className="rounded-2xl p-4 font-bold gap-3 justify-center bg-primary text-primary-foreground mb-2 mt-2 focus:opacity-90">
                     SIGN IN
                  </DropdownMenuItem>
                  <DropdownMenuItem className="rounded-2xl p-4 font-bold gap-3 justify-center border-2 border-border focus:bg-secondary">
                     CREATE ACCOUNT
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Mobile Menu Sidebar */}
      {isMobileMenuOpen && (
        <div className="lg:hidden absolute top-20 left-0 w-full bg-background border-b border-border p-6 shadow-2xl animate-in slide-in-from-top-4 duration-300">
           <div className="flex flex-col gap-4">
              {navLinks.map((link) => (
                <a 
                  key={link.name} 
                  href={link.href} 
                  className="p-4 rounded-2xl flex items-center justify-between font-black uppercase text-lg hover:bg-secondary"
                >
                  <span className="flex items-center gap-3">
                    <link.icon className="h-6 w-6 text-primary" /> {link.name}
                  </span>
                  <ChevronRight className="h-5 w-5" />
                </a>
              ))}
           </div>
        </div>
      )}
    </nav>
  );
}

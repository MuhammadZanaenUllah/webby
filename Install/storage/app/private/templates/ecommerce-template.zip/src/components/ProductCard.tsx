import { Star, ShoppingCart, Heart } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardFooter } from './ui/card';
import { Badge } from './ui/badge';
import { formatPrice } from '../lib/format';
import { Product } from '../lib/sample-data';

interface ProductCardProps {
  product: Product;
  onAddToCart?: (product: Product) => void;
}

export function ProductCard({ product, onAddToCart }: ProductCardProps) {
  return (
    <Card className="group relative overflow-hidden transition-all hover:shadow-xl border-border/50">
      <div className="aspect-[4/5] overflow-hidden relative">
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        {product.isNew && (
          <Badge className="absolute top-4 left-4 bg-primary text-primary-foreground">New Arrival</Badge>
        )}
        {product.isSale && (
          <Badge className="absolute top-4 right-4 bg-destructive text-destructive-foreground">Sale</Badge>
        )}
        <div className="absolute inset-0 bg-black/40 opacity-0 transition-opacity group-hover:opacity-100 flex items-center justify-center gap-4">
          <Button
            size="icon"
            variant="secondary"
            className="rounded-full h-10 w-10 hover:bg-primary hover:text-white transition-colors"
          >
            <Heart className="h-5 w-5" />
          </Button>
          <Button
            size="icon"
            variant="secondary"
            onClick={() => onAddToCart?.(product)}
            className="rounded-full h-10 w-10 hover:bg-primary hover:text-white transition-colors"
          >
            <ShoppingCart className="h-5 w-5" />
          </Button>
        </div>
      </div>
      <CardContent className="p-4">
        <div className="flex justify-between items-start mb-2">
          <p className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">
            {product.category}
          </p>
          <div className="flex items-center gap-1 text-xs font-medium bg-secondary/50 px-2 py-0.5 rounded">
            <Star className="h-3 w-3 fill-yellow-500 text-yellow-500" />
            <span>{product.rating}</span>
          </div>
        </div>
        <h3 className="font-bold text-lg mb-1 group-hover:text-primary transition-colors line-clamp-1">
          {product.name}
        </h3>
        <p className="text-sm text-muted-foreground line-clamp-2 mb-4 leading-relaxed">
          {product.description}
        </p>
        <div className="flex items-center gap-3">
          <span className="text-xl font-black text-foreground">
            {formatPrice(product.isSale ? product.discountPrice! : product.price)}
          </span>
          {product.isSale && (
            <span className="text-sm text-muted-foreground line-through decoration-destructive/30">
              {formatPrice(product.price)}
            </span>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

interface CategoryCardProps {
  name: string;
  count: number;
  image: string;
}

export function CategoryCard({ name, count, image }: CategoryCardProps) {
  return (
    <div className="group relative aspect-video overflow-hidden rounded-2xl cursor-pointer shadow-lg">
      <img
        src={image}
        alt={name}
        className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex flex-col justify-end p-6">
        <h3 className="text-2xl font-bold text-white mb-1">{name}</h3>
        <p className="text-white/70 text-sm font-medium">{count} Items Available</p>
      </div>
    </div>
  );
}
